<?php
//DB credentials
define("DATABASE", "aay33372022");
define("SERVER", "localhost");
define("USERNAME", "root");
define("PASSWD", "Fl45h.12345..");

?>